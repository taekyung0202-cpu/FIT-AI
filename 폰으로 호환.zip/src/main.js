
import './style.css';

const clothes = [
  { id: 1, name: '라벤더 후드티', type: 'top', emoji: '🧥', color: '#d9c8ff', style: '캐주얼' },
  { id: 2, name: '크림 니트', type: 'top', emoji: '🧶', color: '#f5e5ce', style: '러블리' },
  { id: 3, name: '핑크 티셔츠', type: 'top', emoji: '👚', color: '#ffd5e8', style: '러블리' },
  { id: 4, name: '하늘색 셔츠', type: 'top', emoji: '👕', color: '#cce8ff', style: '베이직' },
  { id: 5, name: '데님 팬츠', type: 'bottom', emoji: '👖', color: '#b8d4ff', style: '캐주얼' },
  { id: 6, name: '핑크 스커트', type: 'bottom', emoji: '👗', color: '#ffd9eb', style: '러블리' },
  { id: 7, name: '크림 팬츠', type: 'bottom', emoji: '👖', color: '#eee1cc', style: '모던' },
  { id: 8, name: '민트 스커트', type: 'bottom', emoji: '👗', color: '#c9f0df', style: '베이직' }
];

let selectedTop = 1;
let selectedBottom = 5;
let cameraStream = null;
let capturedPhoto = null;
let favorites = [];
let cameraMode = 'none';

const app = document.querySelector('#app');

app.innerHTML = `
<header class="topbar">
  <a class="logo" href="#">♡ FitCam AI</a>
  <nav>
    <button class="nav-btn active" data-page="home">⌂ 홈</button>
    <button class="nav-btn" data-page="fitting">의상 둘러보기</button>
    <button class="nav-btn" data-page="recommend">AI 코디 추천</button>
    <button class="nav-btn" data-page="favorites">♡ 찜한 코디</button>
  </nav>
  <button class="login-btn" id="loginBtn">로그인</button>
</header>

<main>
  <section id="home" class="page active">
    <div class="hero">
      <div class="hero-copy">
        <span class="eyebrow">✦ MY STYLE, MY MAGIC ✦</span>
        <h1>나만의 스타일을<br>AI와 함께!</h1>
        <p>웹캠으로 나의 모습을 확인하고<br>
        마음에 드는 코디를 귀엽게 골라봐요.</p>
        <button class="primary" data-page="fitting">가상 피팅 시작하기 →</button>
        <button class="secondary" data-page="recommend">코디 추천받기</button>
      </div>
      <div class="mascot">🐰<span>♡</span></div>
      <span class="sparkle sparkle-one">✦</span>
      <span class="sparkle sparkle-two">♡</span>
    </div>

    <div class="feature-row">
      <button class="feature" data-page="fitting"><span>📸</span><b>가상 피팅</b><small>카메라로 미리보기</small></button>
      <button class="feature" data-page="recommend"><span>✨</span><b>AI 코디 추천</b><small>나만의 스타일 찾기</small></button>
      <button class="feature" data-page="fitting"><span>👚</span><b>의상 둘러보기</b><small>다양한 옷 구경하기</small></button>
      <button class="feature" data-page="favorites"><span>💗</span><b>찜한 코디</b><small>마음에 드는 코디 저장</small></button>
    </div>

    <section class="panel">
      <div class="section-heading">
        <div><h2>오늘의 귀여운 아이템 🌷</h2><p>마음에 드는 옷을 골라 피팅해 보세요.</p></div>
        <button class="text-btn" data-page="fitting">전체 보기 →</button>
      </div>
      <div class="product-grid" id="homeProducts"></div>
    </section>
  </section>

  <section id="fitting" class="page">
    <div class="page-heading"><h1>나만의 가상 피팅룸 ♡</h1><p>카메라를 켜고 마음에 드는 옷을 선택해 봐요!</p></div>
    <div class="fitting-layout">
      <aside class="panel clothing-panel">
        <h2>상의 선택 👚</h2>
        <div class="clothing-grid" id="tops"></div>
        <h2 class="space-top">하의 선택 👖</h2>
        <div class="clothing-grid" id="bottoms"></div>
        <div class="tip">💡 옷을 선택하면 피팅 화면의 미리보기가 바뀌어요.</div>
      </aside>

      <section class="panel fitting-panel">
        <div class="section-heading">
          <div><h2>나의 피팅룸</h2><p>사진은 이 브라우저 안에서만 처리돼요.</p></div>
          <span class="live-badge">● LIVE</span>
        </div>
        <div class="camera-stage" id="cameraStage">
          <div class="camera-placeholder">
            <span class="camera-icon">📸</span>
            <h3>피팅룸에 오신 걸 환영해요!</h3>
            <p>카메라를 켜거나 사진을 업로드해 주세요.</p>
          </div>
        </div>
        <div class="camera-controls">
          <button class="primary" id="startCamera">📷 카메라 켜기</button>
          <button class="secondary" id="takePhoto">사진 촬영</button>
          <button class="secondary" id="uploadButton">사진 업로드</button>
          <button class="secondary" id="stopCamera">카메라 끄기</button>
          <input id="photoInput" type="file" accept="image/*" hidden>
        </div>
        <div class="outfit-summary">
          <span>오늘의 선택 코디 💜</span>
          <h3 id="outfitName">라벤더 후드티 + 데님 팬츠</h3>
          <p>선택한 옷으로 나만의 스타일을 만들어 봐요.</p>
          <button class="primary" id="saveOutfit">♡ 코디 저장하기</button>
          <button class="secondary" id="randomOutfit">다른 조합 추천</button>
        </div>
        <p class="notice">현재 옷 표시는 미리보기용 그래픽입니다. 실제 신체에 맞춰 옷을 합성하는 AI는 아직 연결되지 않았어요.</p>
      </section>
    </div>
  </section>

  <section id="recommend" class="page">
    <div class="page-heading"><h1>AI 코디 추천 ✨</h1><p>오늘의 취향을 선택하면 어울리는 코디를 골라드려요.</p></div>
    <div class="panel preference-panel">
      <h2>어떤 스타일을 좋아하나요?</h2>
      <div class="choice-row" id="styleChoices">
        <button class="choice active" data-style="러블리">🎀 러블리</button>
        <button class="choice" data-style="캐주얼">🧸 캐주얼</button>
        <button class="choice" data-style="베이직">🤍 베이직</button>
        <button class="choice" data-style="모던">🌷 모던</button>
      </div>
      <h2>어떤 날에 입을까요?</h2>
      <div class="choice-row" id="occasionChoices">
        <button class="choice active" data-occasion="일상">☁️ 일상</button>
        <button class="choice" data-occasion="데이트">💗 데이트</button>
        <button class="choice" data-occasion="학교">🎒 학교</button>
        <button class="choice" data-occasion="특별한 날">✨ 특별한 날</button>
      </div>
      <button class="primary" id="recommendButton">✨ 내 코디 추천받기</button>
    </div>
    <div class="panel recommendation-result">
      <div class="section-heading"><div><h2>오늘의 추천 코디</h2><p id="recommendCaption">러블리한 일상 코디를 골라봤어요.</p></div></div>
      <div class="recommendation-cards" id="recommendationCards"></div>
      <div class="reason-box"><b>💌 추천 이유</b><p id="recommendReason">부드러운 색상과 편안한 아이템을 조합했어요.</p></div>
      <button class="primary" id="tryRecommended">이 코디 입어보기 →</button>
    </div>
  </section>

  <section id="favorites" class="page">
    <div class="page-heading"><h1>내가 찜한 코디 💗</h1><p>좋아하는 조합을 모아두고 다시 확인해 봐요.</p></div>
    <section class="panel"><div id="favoriteList" class="product-grid"></div></section>
  </section>
</main>
<div class="toast" id="toast"></div>
<footer>♡ FitCam AI · 나만의 스타일을 AI와 함께 ♡</footer>
`;

const $ = selector => document.querySelector(selector);

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 2200);
}

function currentItem(id) {
  return clothes.find(item => item.id === id);
}

function itemCard(item, selectable = false) {
  const selected = item.id === selectedTop || item.id === selectedBottom;
  return `
    <button class="item-card ${selectable && selected ? 'selected' : ''}"
      data-item="${item.id}" style="--item-color:${item.color}">
      <span class="item-emoji">${item.emoji}</span>
      <span class="item-name">${item.name}</span>
      <span class="item-style">${item.style}</span>
      <span class="item-heart">${favorites.some(f => f.id === item.id) ? '♥' : '♡'}</span>
    </button>`;
}

function renderClothing() {
  $('#tops').innerHTML = clothes.filter(x => x.type === 'top').map(x => itemCard(x, true)).join('');
  $('#bottoms').innerHTML = clothes.filter(x => x.type === 'bottom').map(x => itemCard(x, true)).join('');
  $('#homeProducts').innerHTML = clothes.slice(0, 6).map(x => itemCard(x)).join('');
  updateOutfit();
}

function updateOutfit() {
  const top = currentItem(selectedTop);
  const bottom = currentItem(selectedBottom);

  $('#outfitName').textContent = `${top.name} + ${bottom.name}`;

  const stage = $('#cameraStage');
  let overlay = $('#clothingOverlay');

  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'clothingOverlay';
    overlay.innerHTML = `
      <div class="virtual-top" id="virtualTop">
        <span id="virtualTopEmoji"></span>
      </div>
      <div class="virtual-bottom" id="virtualBottom">
        <span id="virtualBottomEmoji"></span>
      </div>`;
    stage.appendChild(overlay);
  }

  $('#virtualTopEmoji').textContent = top.emoji;
  $('#virtualBottomEmoji').textContent = bottom.emoji;
  $('#virtualTop').style.setProperty('--garment-color', top.color);
  $('#virtualBottom').style.setProperty('--garment-color', bottom.color);

  overlay.style.display = cameraMode === 'none' ? 'none' : 'block';

  document.querySelectorAll('[data-item]').forEach(button => {
    const id = Number(button.dataset.item);
    button.classList.toggle('selected', id === selectedTop || id === selectedBottom);
    const heart = button.querySelector('.item-heart');
    if (heart) heart.textContent = favorites.some(f => f.id === id) ? '♥' : '♡';
  });
}

function renderFavorites() {
  const list = $('#favoriteList');
  if (!favorites.length) {
    list.innerHTML = '<div class="empty-state">💗<h3>아직 찜한 옷이 없어요.</h3><p>마음에 드는 아이템의 하트를 눌러 저장해 보세요!</p></div>';
    return;
  }

  list.innerHTML = favorites.map(item => `
    <div class="favorite-card">
      <div class="favorite-emoji" style="background:${item.color}">${item.emoji}</div>
      <b>${item.name}</b>
      <small>${item.style}</small>
      <button class="secondary remove-favorite" data-remove="${item.id}">찜 취소</button>
    </div>`).join('');
}

function navigate(page) {
  document.querySelectorAll('.page').forEach(el => {
    el.classList.toggle('active', el.id === page);
  });
  document.querySelectorAll('[data-page].nav-btn').forEach(el => {
    el.classList.toggle('active', el.dataset.page === page);
  });
  if (page === 'favorites') renderFavorites();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.addEventListener('click', event => {
  const pageButton = event.target.closest('[data-page]');
  if (pageButton) {
    navigate(pageButton.dataset.page);
    return;
  }

  const itemButton = event.target.closest('[data-item]');
  if (itemButton) {
    const item = currentItem(Number(itemButton.dataset.item));

    if (item.type === 'top') selectedTop = item.id;
    else selectedBottom = item.id;

    updateOutfit();
    updateRecommendationCards();
    return;
  }

  const removeButton = event.target.closest('[data-remove]');
  if (removeButton) {
    favorites = favorites.filter(item => item.id !== Number(removeButton.dataset.remove));
    renderFavorites();
    renderClothing();
    showToast('찜 목록에서 삭제했어요.');
  }
});

document.addEventListener('click', event => {
  const choice = event.target.closest('[data-style]');
  if (choice) {
    document.querySelectorAll('[data-style]').forEach(b => b.classList.remove('active'));
    choice.classList.add('active');
  }

  const occasion = event.target.closest('[data-occasion]');
  if (occasion) {
    document.querySelectorAll('[data-occasion]').forEach(b => b.classList.remove('active'));
    occasion.classList.add('active');
  }
});

async function startCamera() {
  if (!navigator.mediaDevices?.getUserMedia) {
    showToast('카메라 사용을 지원하지 않는 환경이에요.');
    return;
  }

  try {
    stopCamera(false);

    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'user' },
      audio: false
    });

    const stage = $('#cameraStage');
    stage.querySelectorAll('video, img').forEach(el => el.remove());

    const video = document.createElement('video');
    video.id = 'cameraVideo';
    video.autoplay = true;
    video.playsInline = true;
    video.muted = true;
    video.srcObject = cameraStream;
    stage.prepend(video);

    cameraMode = 'video';
    updateOutfit();
    showToast('카메라가 켜졌어요! 📸');
  } catch (error) {
    console.error(error);
    showToast('카메라 권한을 허용해 주세요.');
  }
}

function stopCamera(showMessage = true) {
  if (cameraStream) {
    cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
  }

  if (cameraMode === 'video') {
    $('#cameraStage').querySelectorAll('video').forEach(el => el.remove());
    cameraMode = capturedPhoto ? 'photo' : 'none';
  }

  updateOutfit();
  if (showMessage) showToast('카메라를 껐어요.');
}

function uploadPhoto(file) {
  if (!file) return;

  if (!file.type.startsWith('image/')) {
    showToast('이미지 파일을 선택해 주세요.');
    return;
  }

  const reader = new FileReader();

  reader.onload = () => {
    capturedPhoto = reader.result;
    stopCamera(false);

    const stage = $('#cameraStage');
    stage.querySelectorAll('video, img').forEach(el => el.remove());

    const img = document.createElement('img');
    img.id = 'uploadedPhoto';
    img.src = capturedPhoto;
    img.alt = '업로드한 피팅 사진';
    stage.prepend(img);

    cameraMode = 'photo';
    updateOutfit();
    showToast('사진을 불러왔어요! 💗');
  };

  reader.readAsDataURL(file);
}

function takePhoto() {
  const video = $('#cameraVideo');

  if (!video || !video.videoWidth) {
    showToast('먼저 카메라를 켜 주세요.');
    return;
  }

  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;

  const ctx = canvas.getContext('2d');
  ctx.translate(canvas.width, 0);
  ctx.scale(-1, 1);
  ctx.drawImage(video, 0, 0);

  capturedPhoto = canvas.toDataURL('image/jpeg', 0.9);

  stopCamera(false);

  const stage = $('#cameraStage');
  stage.querySelectorAll('video, img').forEach(el => el.remove());

  const img = document.createElement('img');
  img.src = capturedPhoto;
  img.alt = '촬영한 피팅 사진';
  stage.prepend(img);

  cameraMode = 'photo';
  updateOutfit();
  showToast('사진 촬영 완료! ✨');
}

$('#startCamera').addEventListener('click', startCamera);
$('#stopCamera').addEventListener('click', () => stopCamera());
$('#takePhoto').addEventListener('click', takePhoto);
$('#uploadButton').addEventListener('click', () => $('#photoInput').click());
$('#photoInput').addEventListener('change', event => uploadPhoto(event.target.files[0]));

$('#saveOutfit').addEventListener('click', () => {
  const ids = [selectedTop, selectedBottom];
  const alreadySaved = favorites.some(item => item.id === selectedTop)
    && favorites.some(item => item.id === selectedBottom);

  ids.forEach(id => {
    const item = currentItem(id);
    if (!favorites.some(saved => saved.id === id)) favorites.push(item);
  });

  renderClothing();
  showToast(alreadySaved ? '이미 찜한 아이템이 있어요 💗' : '아이템을 찜했어요! 💗');
});

$('#randomOutfit').addEventListener('click', () => {
  const tops = clothes.filter(x => x.type === 'top');
  const bottoms = clothes.filter(x => x.type === 'bottom');

  selectedTop = tops[Math.floor(Math.random() * tops.length)].id;
  selectedBottom = bottoms[Math.floor(Math.random() * bottoms.length)].id;

  updateOutfit();
  updateRecommendationCards();
  showToast('새로운 코디를 골랐어요! 🌷');
});

function updateRecommendationCards() {
  const top = currentItem(selectedTop);
  const bottom = currentItem(selectedBottom);

  $('#recommendationCards').innerHTML = [top, bottom].map(item => `
    <div class="recommend-item">
      <div class="recommend-emoji" style="background:${item.color}">${item.emoji}</div>
      <b>${item.name}</b>
      <small>${item.style} 스타일</small>
    </div>`).join('');
}

function recommendOutfit() {
  const style = $('[data-style].active')?.dataset.style || '러블리';
  const occasion = $('[data-occasion].active')?.dataset.occasion || '일상';

  const styleMap = {
    러블리: { top: 3, bottom: 6, reason: '핑크 계열의 부드러운 색감으로 사랑스러운 분위기를 만들었어요.' },
    캐주얼: { top: 1, bottom: 5, reason: '편안한 후드티와 데님 팬츠를 조합해 활동하기 좋은 룩이에요.' },
    베이직: { top: 4, bottom: 7, reason: '차분한 색상과 기본 아이템으로 깔끔한 스타일을 완성했어요.' },
    모던: { top: 2, bottom: 7, reason: '크림색 니트와 차분한 팬츠로 단정한 느낌을 살렸어요.' }
  };

  const result = styleMap[style] || styleMap.러블리;
  selectedTop = result.top;
  selectedBottom = result.bottom;

  $('#recommendCaption').textContent = `${style} 스타일 · ${occasion} 코디`;
  $('#recommendReason').textContent =
    `${occasion}에 어울리는 코디예요. ${result.reason}`;

  updateOutfit();
  updateRecommendationCards();
  showToast('취향에 맞는 코디를 골랐어요! ✨');
}

$('#recommendButton').addEventListener('click', recommendOutfit);
$('#tryRecommended').addEventListener('click', () => navigate('fitting'));
$('#loginBtn').addEventListener('click', () => {
  showToast('로그인 기능은 다음 단계에서 추가할 수 있어요.');
});

renderClothing();
updateRecommendationCards();
renderFavorites();
