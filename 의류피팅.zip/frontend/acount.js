import { api } from './common.js';

const $ = id => document.getElementById(id);
const msg = (t, err = false) => {
  const m = $('authMsg');
  m.textContent = t;
  m.style.color = err ? '#e5484d' : '#30a46c';
};

async function init() {
  const app = window.fitApp;
  if (!app || !app.addCloth) {
    return msg('app.js 맨 아래의 fitApp 코드가 최신이 아닙니다. 위 코드로 교체한 뒤 Ctrl+F5를 누르세요.', true);
  }

  let me = null;
  try { me = await api('/api/me'); } catch { /* 로그아웃 상태 */ }

  if (!me) {
    msg('로그인하면 피팅함의 옷을 이 화면에서 입어볼 수 있습니다.');
  } else {
    $('userBox').textContent = me.email + ' 님으로 로그인됨';
    $('saveProfileBtn').hidden = false;
    if (me.profile) app.applyProfile(me.profile);

    try {
      const items = await api('/api/closet');
      for (const it of items) {
        app.addCloth('c' + it.id, { name: it.name, type: it.type, ...it.dims });
      }
      msg(items.length ? `피팅함 옷 ${items.length}개를 불러왔습니다. 아래 "의류 / 핏"에서 선택하세요.`
                       : '피팅함이 비어 있습니다. "내 피팅함"에서 옷을 담아보세요.');
      // 피팅함에서 "입어보기"로 들어온 경우 그 옷을, 아니면 가장 최근 옷을 선택
      const want = new URLSearchParams(location.search).get('cloth');
      if (want) app.setCloth(want);
      else if (items.length) app.setCloth('c' + items[0].id);
    } catch (e) {
      msg('피팅함을 불러오지 못했습니다: ' + e.message, true);
    }
  }
}

$('saveProfileBtn').onclick = async () => {
  try {
    await api('/api/profile', 'PUT', window.fitApp.getProfile());
    msg('내 치수와 스타일을 저장했습니다.');
  } catch (e) { msg(e.message, true); }
};

init();