export async function api(path, method = 'GET', body) {
  const r = await fetch(path, {
    method, credentials: 'same-origin',
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!r.ok) {
    let m = '요청에 실패했습니다.';
    if (r.status === 422) m = '입력값을 확인하세요. (이메일 형식, 비밀번호 8자 이상)';
    else { try { const j = await r.json(); if (typeof j.detail === 'string') m = j.detail; } catch {} }
    throw new Error(m);
  }
  return r.json();
}

export function el(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e[k] = v;
    else e.setAttribute(k, v);
  }
  e.append(...kids);
  return e;
}

export async function mountAuth(onChange = () => {}) {
  let mode = 'login', user = null;
  const bar = document.getElementById('topbar');
  if (bar) bar.innerHTML = `<a class="logo" href="index.html">AI 의류 피팅</a>
    <nav><a href="fitting.html">3D 피팅</a><a href="closet.html">옷 찾기·피팅함</a></nav><div id="authArea"></div>`;

  const dlg = document.createElement('dialog');
  dlg.innerHTML = `<form id="authForm"><h2 id="authTitle"></h2>
    <input type="email" id="email" placeholder="이메일" autocomplete="username" required>
    <input type="password" id="password" placeholder="비밀번호 (8자 이상)" minlength="8" autocomplete="current-password" required>
    <label id="consentRow" class="consent"><input type="checkbox" id="consent"> 신체 치수를 서버에 저장하는 것에 동의합니다</label>
    <div id="authMsg" class="err"></div>
    <div class="cta"><button class="btn primary">확인</button><button type="button" class="btn" id="authCancel">닫기</button></div></form>`;
  document.body.append(dlg);
  const q = s => dlg.querySelector(s);

  function open(m) {
    mode = m;
    q('#authTitle').textContent = m === 'login' ? '로그인' : '회원가입';
    q('#consentRow').hidden = m === 'login';
    q('#authMsg').textContent = '';
    dlg.showModal();
  }
  function render() {
    const area = document.getElementById('authArea');
    if (area) area.replaceChildren(...(user
      ? [el('span', { class: 'mute' }, user.email), el('button', { class: 'btn', onclick: logout }, '로그아웃')]
      : [el('button', { class: 'btn', onclick: () => open('login') }, '로그인'),
         el('button', { class: 'btn primary', onclick: () => open('signup') }, '회원가입')]));
    document.querySelectorAll('.guest-only').forEach(n => n.hidden = !!user);
    document.querySelectorAll('[data-auth]').forEach(b => b.onclick = () => open(b.dataset.auth));
    onChange(user);
  }
  async function refresh() { try { user = await api('/api/me'); } catch { user = null; } render(); }
  async function logout() { await api('/api/auth/logout', 'POST'); user = null; render(); }

  q('#authCancel').onclick = () => dlg.close();
  q('#authForm').onsubmit = async e => {
    e.preventDefault();
    const m = q('#authMsg');
    if (mode === 'signup' && !q('#consent').checked) { m.textContent = '신체 치수 저장에 동의해야 가입할 수 있습니다.'; return; }
    try {
      await api('/api/auth/' + mode, 'POST', { email: q('#email').value.trim(), password: q('#password').value });
      q('#password').value = ''; dlg.close(); await refresh();
    } catch (err) { m.textContent = err.message; }
  };
  await refresh();
}