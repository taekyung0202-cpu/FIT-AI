import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const $ = id => document.getElementById(id);

/* ───────────── 설정 데이터 ───────────── */
// GLB 파일을 구하면 경로를 적으세요. null이면 내장 마네킹을 사용합니다.
const ASSETS = {
  body: { male: null /* 'models/body_male.glb' */, female: null /* 'models/body_female.glb' */ },
};

const DEFAULTS = {            // 모든 값은 cm (가로 '너비' 기준)
  male:   { height: 175, shoulder: 44, chest: 34, waist: 30, hip: 35, arm: 10, thigh: 18, calf: 12, foot: 270 },
  female: { height: 162, shoulder: 38, chest: 29, waist: 25, hip: 34, arm: 8,  thigh: 17, calf: 11, foot: 240 },
};
const SLIDERS = [
  ['height','키',140,200],['shoulder','어깨너비',30,56],['chest','가슴너비',22,45],
  ['waist','허리너비',18,42],['hip','엉덩이너비',26,46],['arm','팔 두께',5,16],
  ['thigh','허벅지 두께',10,28],['calf','종아리 두께',7,18],
];
const HAIR = {
  female: { '단발': 'bob', '장발': 'long' },
  male:   { '짧은 머리': 'short', '장발': 'long' },
};
const HAIR_COLORS = [['블랙','#1a1a1a'],['다크브라운','#3b2a20'],['브라운','#6b4423'],
                     ['금발','#d9b34f'],['레드브라운','#8a2b1b'],['애쉬그레이','#9a9a9a']];
const SHOES = { '스니커즈':{h:.08,col:'#f2f2f2'}, '로퍼':{h:.07,col:'#3b2a20'},
                '부츠':{h:.20,col:'#1a1a1a'}, '샌들':{h:.03,col:'#c9a27a'} };
const SHOE_COLORS = ['#f2f2f2','#1a1a1a','#3b2a20','#c9a27a','#e5484d','#3e63dd'];
// 의류 사이즈표: 옷 단면 너비(cm)
const CLOTHES = {
  top_s:   { name:'티셔츠 S',  type:'top',    shoulder:40, chest:30, waist:28 },
  top_m:   { name:'티셔츠 M',  type:'top',    shoulder:43, chest:34, waist:32 },
  top_l:   { name:'티셔츠 L',  type:'top',    shoulder:46, chest:38, waist:36 },
  pants_s: { name:'바지 S',    type:'bottom', waist:26, hip:32, thigh:17 },
  pants_m: { name:'바지 M',    type:'bottom', waist:30, hip:36, thigh:20 },
  pants_l: { name:'바지 L',    type:'bottom', waist:34, hip:40, thigh:23 },
};
const PART_LABEL = { shoulder:'어깨', chest:'가슴', waist:'허리', hip:'엉덩이', thigh:'허벅지' };

/* ───────────── 상태 ───────────── */
const state = {
  gender: 'female', body: { ...DEFAULTS.female }, hair: '장발', hairColor: '#3b2a20',
  shoe: '스니커즈', shoeColor: '#f2f2f2', cloth: 'top_m',
};

/* ───────────── 3D 기본 세팅 ───────────── */
const viewer = $('viewer');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x14171c);
const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 50);
camera.position.set(0, 1.0, 3.6);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
viewer.appendChild(renderer.domElement);
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 0.9, 0);
controls.enableDamping = true;
scene.add(new THREE.HemisphereLight(0xffffff, 0x333344, 1.1));
const key = new THREE.DirectionalLight(0xffffff, 1.6); key.position.set(2, 4, 3); scene.add(key);
const floor = new THREE.Mesh(new THREE.CircleGeometry(1.2, 48),
  new THREE.MeshStandardMaterial({ color: 0x222831 }));
floor.rotation.x = -Math.PI / 2; scene.add(floor);

function resize() {
  const w = viewer.clientWidth, h = viewer.clientHeight;
  renderer.setSize(w, h); camera.aspect = w / h; camera.updateProjectionMatrix();
}
addEventListener('resize', resize); resize();
(function loop() { requestAnimationFrame(loop); controls.update(); renderer.render(scene, camera); })();

/* ───────────── 아바타 생성 ───────────── */
const avatar = new THREE.Group(); scene.add(avatar);
const mat = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: .8, ...o });
const SKIN = () => mat(state.gender === 'male' ? 0xd9a98a : 0xe3b9a0);

// 타원 기둥: 너비w, 높이h, 깊이d (m)
function ell(w, h, d, x, y, z, m) {
  const o = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 1, 32), m);
  o.scale.set(w / 2, h, d / 2); o.position.set(x, y, z); return o;
}
function headInfo(H) { return { y: H * 0.925, r: H * 0.062 }; }

function buildProceduralBody(p, g) {
  const H = p.height / 100, c = v => v / 100, s = SKIN();
  const sh = c(p.shoulder), ch = c(p.chest), wa = c(p.waist), hi = c(p.hip);
  const arm = c(p.arm), th = c(p.thigh), ca = c(p.calf);
  // 몸통 (깊이는 너비의 약 60%)
  g.add(ell(hi, H*.10, hi*.62, 0, H*.52, 0, s));
  g.add(ell(wa, H*.10, wa*.62, 0, H*.61, 0, s));
  g.add(ell(ch, H*.12, ch*.66, 0, H*.71, 0, s));
  g.add(ell(sh, H*.035, ch*.55, 0, H*.795, 0, s));              // 어깨선
  g.add(ell(H*.05, H*.05, H*.05, 0, H*.85, 0, s));               // 목
  const { y, r } = headInfo(H);
  const head = new THREE.Mesh(new THREE.SphereGeometry(r, 32, 24), s);
  head.scale.set(.88, 1.12, 1); head.position.set(0, y, 0); g.add(head);
  for (const sd of [-1, 1]) {
    const ax = sd * (sh / 2 + arm / 2 * .6);
    g.add(ell(arm, H*.17, arm, ax, H*.72, 0, s));                // 상완
    g.add(ell(arm*.8, H*.16, arm*.8, ax * 1.04, H*.55, 0, s));   // 하완
    const lx = sd * hi * .24;
    g.add(ell(th, H*.24, th, lx, H*.40, 0, s));                  // 허벅지
    g.add(ell(ca, H*.24, ca, lx, H*.16, 0, s));                  // 종아리
    const f = c(p.foot ?? 240); // 맨발
    const foot = new THREE.Mesh(new THREE.BoxGeometry(f*.38, .03, f), s);
    foot.position.set(lx, .015, f/2 - .06); g.add(foot);
  }
}

// GLB 본 이름 퍼지 검색 → 스케일 적용
function applyGLBBody(model, p) {
  const bones = {}; model.traverse(o => o.isBone && (bones[o.name.toLowerCase()] = o));
  const find = re => Object.values(bones).find(b => re.test(b.name.toLowerCase()));
  const d = DEFAULTS[state.gender], r = k => p[k] / d[k];
  model.scale.setScalar(p.height / d.height);
  const set = (re, x, y = 1, z = x) => { const b = find(re); b && b.scale.set(x, y, z); };
  set(/spine2|chest/, r('chest'), 1, r('chest'));
  set(/spine$|spine1/, r('waist'), 1, r('waist'));
  set(/hips/, r('hip'), 1, r('hip'));
  set(/leftshoulder|l_shoulder/, 1, r('shoulder'), 1);
  set(/rightshoulder|r_shoulder/, 1, r('shoulder'), 1);
  set(/leftarm$|l_upperarm/, 1, r('arm'), r('arm'));  set(/rightarm$|r_upperarm/, 1, r('arm'), r('arm'));
  set(/leftupleg|l_thigh/, r('thigh'), 1, r('thigh')); set(/rightupleg|r_thigh/, r('thigh'), 1, r('thigh'));
  set(/leftleg$|l_calf/, r('calf'), 1, r('calf'));     set(/rightleg$|r_calf/, r('calf'), 1, r('calf'));
}

function buildHair(g, H) {
  const { y, r } = headInfo(H), type = HAIR[state.gender][state.hair];
  const m = mat(state.hairColor, { side: THREE.DoubleSide, roughness: .6 });
  const cap = new THREE.Mesh(new THREE.SphereGeometry(r*1.08, 32, 20, 0, Math.PI*2, 0, Math.PI*.56), m);
  cap.scale.set(.9, 1.12, 1.04); cap.position.set(0, y + r*.04, -r*.02); g.add(cap);
  if (type === 'short') return;
  // 뒷머리 (뒤쪽 반구만)
  const len = type === 'bob' ? r*1.7 : r*4.4;
  const back = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 20, Math.PI, Math.PI), m);
  back.scale.set(r*1.02, len, r*1.12);
  back.position.set(0, y - len*.62 + r*.3, -r*.02); g.add(back);
}

function buildShoes(g, p) {
  const sp = SHOES[state.shoe], len = p.foot / 1000, w = len * .38;
  const m = mat(state.shoeColor, { roughness: .5 });
  const hi = p.hip / 100 * .24;
  for (const sd of [-1, 1]) {
    const body = new THREE.Mesh(new THREE.BoxGeometry(w, sp.h, len), m);
    body.position.set(sd * hi, sp.h / 2 + .01, len / 2 - .06);
    g.add(body);
    if (sp.h > .06) {                                               // 발목 부분
      const up = new THREE.Mesh(new THREE.CylinderGeometry(w*.42, w*.46, sp.h*1.1, 20), m);
      up.position.set(sd * hi, sp.h * .9, 0); g.add(up);
    }
  }
}

/* ───────────── 핏 계산 (브라우저 내에서만 처리) ───────────── */
function judge(diff) { return diff < 0.5 ? 'tight' : diff <= 5 ? 'fit' : 'loose'; }
const FIT_COLOR = { tight: 0xe5484d, fit: 0x30a46c, loose: 0x3e63dd };
const FIT_TEXT = { tight: '타이트', fit: '적당', loose: '여유' };

function evaluateFit() {
  const c = CLOTHES[state.cloth], res = {};
  for (const k of Object.keys(PART_LABEL)) if (c[k] != null) res[k] = judge(c[k] - state.body[k]);
  return res;
}
function renderFitText(res) {
  $('fitResult').innerHTML = Object.entries(res).map(([k, v]) =>
    `<div><span>${PART_LABEL[k]}</span><b style="color:#${FIT_COLOR[v].toString(16).padStart(6,'0')}">${FIT_TEXT[v]}</b></div>`).join('');
}

function buildCloth(g, p, res) {
  const c = CLOTHES[state.cloth], H = p.height / 100, w = v => v / 100;
  const mk = part => new THREE.MeshStandardMaterial({
    color: FIT_COLOR[res[part]], transparent: true, opacity: .72, roughness: .9 });
  if (c.type === 'top') {
    g.add(ell(w(c.waist) + .01, H*.11, w(c.waist)*.66, 0, H*.615, 0, mk('waist')));
    g.add(ell(w(c.chest) + .01, H*.13, w(c.chest)*.70, 0, H*.715, 0, mk('chest')));
    g.add(ell(w(c.shoulder) + .01, H*.04, w(c.chest)*.60, 0, H*.795, 0, mk('shoulder')));
  } else {
    g.add(ell(w(c.waist) + .01, H*.06, w(c.waist)*.66, 0, H*.585, 0, mk('waist')));
    g.add(ell(w(c.hip) + .01, H*.12, w(c.hip)*.66, 0, H*.515, 0, mk('hip')));
    for (const sd of [-1, 1])
      g.add(ell(w(c.thigh) + .01, H*.30, w(c.thigh) + .01, sd * w(p.hip) * .24, H*.36, 0, mk('thigh')));
  }
}

/* ───────────── 전체 재구성 ───────────── */
let glbCache = {};
async function loadBodyGLB(url) {
  if (!glbCache[url]) glbCache[url] = new GLTFLoader().loadAsync(url);
  return (await glbCache[url]).scene.clone(true);
}
let token = 0;
async function rebuild() {
  const my = ++token, p = state.body, H = p.height / 100;
  const g = new THREE.Group(), url = ASSETS.body[state.gender];
  let usedGLB = false;
  if (url) {
    try { const m = await loadBodyGLB(url); applyGLBBody(m, { ...p }); g.add(m); usedGLB = true; }
    catch (e) { console.warn('GLB 로드 실패, 내장 모델 사용:', e); }
  }
  if (my !== token) return;                       // 더 최신 요청이 있으면 중단
  if (!usedGLB) buildProceduralBody(p, g);
  buildHair(g, H); buildShoes(g, p);
  const res = evaluateFit(); buildCloth(g, p, res); renderFitText(res);
  avatar.traverse(o => { o.geometry?.dispose?.(); o.material?.dispose?.(); });
  avatar.clear(); avatar.add(g);
  controls.target.set(0, H * .52, 0);
}

/* ───────────── UI 연결 ───────────── */
function swatches(el, list, onPick) {
  el.innerHTML = '';
  list.forEach(([name, col]) => {
    const b = document.createElement('button');
    b.style.background = col; b.title = name;
    b.onclick = () => { onPick(col); [...el.children].forEach(x => x.classList.toggle('on', x === b)); };
    el.appendChild(b);
  });
}
function buildSliders() {
  $('sliders').innerHTML = '';
  SLIDERS.forEach(([k, label, min, max]) => {
    const d = document.createElement('div'); d.className = 'slider';
    d.innerHTML = `<div class="top"><span>${label}</span><output id="o_${k}">${state.body[k]}</output></div>
      <input type="range" id="s_${k}" min="${min}" max="${max}" step="0.5" value="${state.body[k]}">`;
    d.querySelector('input').oninput = e => {
      state.body[k] = +e.target.value; $('o_' + k).textContent = e.target.value; rebuild();
    };
    $('sliders').appendChild(d);
  });
}
function fillHair() {
  const names = Object.keys(HAIR[state.gender]);
  $('hairStyle').innerHTML = names.map(n => `<option>${n}</option>`).join('');
  state.hair = names[names.length - 1]; $('hairStyle').value = state.hair;
}
function setGender(g) {
  state.gender = g; state.body = { ...DEFAULTS[g] };
  document.querySelectorAll('#genderSeg button').forEach(b => b.classList.toggle('on', b.dataset.gender === g));
  $('footSize').value = state.body.foot; buildSliders(); fillHair(); rebuild();
}

document.querySelectorAll('#genderSeg button').forEach(b => b.onclick = () => setGender(b.dataset.gender));
$('hairStyle').onchange = e => { state.hair = e.target.value; rebuild(); };
$('hairColor').oninput = e => { state.hairColor = e.target.value; rebuild(); };
$('footSize').oninput = e => { state.body.foot = Math.min(310, Math.max(200, +e.target.value || 240)); rebuild(); };
$('shoeType').innerHTML = Object.keys(SHOES).map(n => `<option>${n}</option>`).join('');
$('shoeType').onchange = e => { state.shoe = e.target.value; state.shoeColor = SHOES[state.shoe].col; rebuild(); };
$('cloth').innerHTML = Object.entries(CLOTHES).map(([k, v]) => `<option value="${k}">${v.name}</option>`).join('');
$('cloth').value = state.cloth;
$('cloth').onchange = e => { state.cloth = e.target.value; rebuild(); };
swatches($('hairSwatches'), HAIR_COLORS, c => { state.hairColor = c; $('hairColor').value = c; rebuild(); });
swatches($('shoeSwatches'), SHOE_COLORS.map(c => [c, c]), c => { state.shoeColor = c; rebuild(); });

setGender('female');
/* ───────────── 계정 기능용 연결 (account.js가 사용) ───────────── */
window.fitApp = {
  getProfile: () => ({
    gender: state.gender, hair: state.hair, hairColor: state.hairColor,
    shoe: state.shoe, shoeColor: state.shoeColor, body: { ...state.body },
  }),
  getCloth: () => state.cloth,
  getFit: () => evaluateFit(),
  setCloth(id) {
    if (!CLOTHES[id]) return;
    state.cloth = id; $('cloth').value = id; rebuild();
  },
  clothName: id => CLOTHES[id]?.name ?? id,
  describeFit: fit => Object.entries(fit)
    .map(([k, v]) => `${PART_LABEL[k] ?? k} ${FIT_TEXT[v] ?? v}`).join(', '),
  applyProfile(p) {
    if (!DEFAULTS[p.gender]) return;
    setGender(p.gender);
    Object.assign(state.body, p.body);
    if (HAIR[p.gender][p.hair]) state.hair = p.hair;
    state.hairColor = p.hairColor;
    if (SHOES[p.shoe]) state.shoe = p.shoe;
    state.shoeColor = p.shoeColor;
    buildSliders();
    $('hairStyle').value = state.hair;
    $('hairColor').value = state.hairColor;
    $('footSize').value = state.body.foot;
    $('shoeType').value = state.shoe;
    rebuild();
  },
  // 피팅함 옷을 "내 피팅함" 그룹으로 드롭다운에 추가
  addCloth(id, c) {
    CLOTHES[id] = c;
    const sel = $('cloth');
    let group = sel.querySelector('optgroup[data-mine]');
    if (!group) {
      group = document.createElement('optgroup');
      group.label = '내 피팅함';
      group.dataset.mine = '1';
      sel.prepend(group);
    }
    const o = document.createElement('option');
    o.value = id;
    o.textContent = c.name;
    group.appendChild(o);
  },
};