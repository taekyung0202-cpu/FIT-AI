import { api, el, mountAuth } from './common.js';

const $ = id => document.getElementById(id);
const PART = { shoulder: '어깨', chest: '가슴', waist: '허리', hip: '엉덩이', thigh: '허벅지' };
const KEYS = { top: ['shoulder', 'chest', 'waist'], bottom: ['waist', 'hip', 'thigh'] };
const dimText = d => Object.entries(d).map(([k, v]) => `${PART[k] ?? k} ${v}cm`).join(' · ');
let user = null, current = 'find';

function note(t, err = false) { const n = $('note'); n.textContent = t; n.style.color = err ? '#e5484d' : '#30a46c'; }

function tab(name) {
  current = name;
  for (const n of ['find', 'mine']) {
    $('tab-' + n).classList.toggle('on', n === name);
    $('pane-' + n).hidden = n !== name;
  }
  note('');
  if (name === 'mine') loadMine();
}

async function search() {
  try {
    const items = await api(`/api/catalog?q=${encodeURIComponent($('q').value)}&category=${$('cat').value}`);
    const grid = $('grid'); grid.replaceChildren();
    if (!items.length) { grid.textContent = '검색 결과가 없습니다.'; return; }
    for (const it of items) {
      const sel = el('select', {}, ...Object.keys(it.sizes).map(s => el('option', { value: s }, s)));
      sel.value = 'M';
      grid.append(el('div', { class: 'card' },
        el('div', { class: 'swatch', style: `background:${it.color}` }),
        el('b', {}, it.name),
        el('small', {}, `${it.brand} · ${it.category === 'top' ? '상의' : '하의'}`),
        el('small', {}, dimText(it.sizes.M) + ' (M)'),
        el('div', { class: 'row2' }, sel,
          el('button', { class: 'btn', onclick: () => addCatalog(it.id, sel.value) }, '피팅함에 담기'))));
    }
  } catch (e) { note(e.message, true); }
}

async function addCatalog(id, size) {
  if (!user) return note('로그인이 필요합니다. 상단의 로그인 버튼을 눌러주세요.', true);
  try { await api('/api/closet/catalog', 'POST', { catalog_id: id, size }); note('피팅함에 담았습니다.'); }
  catch (e) { note(e.message, true); }
}

async function loadMine() {
  const box = $('mine'); box.replaceChildren();
  $('mineGuest').hidden = !!user;
  $('customBox').hidden = !user;
  if (!user) return;
  try {
    const items = await api('/api/closet');
    if (!items.length) { box.textContent = '아직 담은 옷이 없습니다. "옷 찾기"에서 담아보세요.'; return; }
    for (const it of items) {
      const thumb = it.has_image
        ? el('img', { src: `/api/closet/${it.id}/image`, alt: '' })
        : el('div', { class: 'ph' });
      box.append(el('div', { class: 'item' }, thumb,
        el('div', {}, el('b', {}, it.name), el('br'),
          el('small', { class: 'mute' }, `${it.type === 'top' ? '상의' : '하의'} · ${dimText(it.dims)}`)),
        el('a', { class: 'btn', href: `fitting.html?cloth=c${it.id}` }, '입어보기'),
        el('button', { class: 'btn', onclick: async () => { await api('/api/closet/' + it.id, 'DELETE'); loadMine(); } }, '삭제')));
    }
  } catch (e) { note(e.message, true); }
}

function renderDimInputs() {
  const box = $('cDims'); box.replaceChildren();
  for (const k of KEYS[$('cType').value]) {
    box.append(el('input', { type: 'number', 'data-k': k, min: 10, max: 70, step: 0.5,
      placeholder: `${PART[k]}너비(cm, 옷을 펼쳐 잰 값)` }));
  }
}

async function toJpeg(file) {
  const bmp = await createImageBitmap(file);
  const s = Math.min(1, 480 / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.82);
}

async function saveCustom() {
  const dims = {};
  for (const i of $('cDims').querySelectorAll('input')) dims[i.dataset.k] = parseFloat(i.value);
  if (!$('cName').value.trim()) return note('옷 이름을 입력하세요.', true);
  if (Object.values(dims).some(v => !(v >= 10 && v <= 70))) return note('치수를 모두 10~70cm로 입력하세요.', true);
  try {
    const f = $('cImg').files[0];
    const image = f ? await toJpeg(f) : null;
    await api('/api/closet/custom', 'POST', { name: $('cName').value.trim(), type: $('cType').value, dims, image });
    $('cName').value = ''; $('cImg').value = ''; renderDimInputs();
    note('피팅함에 저장했습니다.'); loadMine();
  } catch (e) { note(e.message, true); }
}

$('tab-find').onclick = () => tab('find');
$('tab-mine').onclick = () => tab('mine');
$('q').oninput = () => { clearTimeout(search.t); search.t = setTimeout(search, 250); };
$('cat').onchange = search;
$('cType').onchange = renderDimInputs;
$('cSave').onclick = saveCustom;
renderDimInputs(); search();
mountAuth(u => { user = u; if (current === 'mine') loadMine(); });