TOP_BASE = {"S": (40, 30, 28), "M": (43, 34, 32), "L": (46, 38, 36), "XL": (49, 42, 40)}
BOT_BASE = {"S": (26, 32, 17), "M": (30, 36, 20), "L": (34, 40, 23), "XL": (38, 44, 26)}
TOP_OFF = {"slim": (-1, -2, -1), "regular": (0, 0, 0), "over": (3, 4, 3)}
BOT_OFF = {"slim": (0, -1, -2), "regular": (0, 0, 0), "wide": (0, 2, 4)}
TOPS = [("베이직 반팔 티셔츠", "regular"), ("슬림핏 셔츠", "slim"), ("오버핏 후디", "over"),
        ("크루넥 맨투맨", "regular"), ("오버핏 반팔 티", "over"), ("슬림 니트", "slim")]
BOTTOMS = [("데님 팬츠", "regular"), ("슬랙스", "slim"), ("와이드 카고 팬츠", "wide"), ("조거 팬츠", "regular")]
COLORS = [("블랙", "#1a1a1a"), ("화이트", "#f2f2f2"), ("네이비", "#1f2d5a"),
          ("베이지", "#d8c3a5"), ("그레이", "#8a8f98")]
BRANDS = ["MODA LAB", "URBAN FIT", "DAILY ATELIER"]


def _build():
    items = []
    for cat, styles, base, off, keys in (
        ("top", TOPS, TOP_BASE, TOP_OFF, ("shoulder", "chest", "waist")),
        ("bottom", BOTTOMS, BOT_BASE, BOT_OFF, ("waist", "hip", "thigh")),
    ):
        for si, (name, fit) in enumerate(styles):
            for ci, (cname, hexc) in enumerate(COLORS):
                sizes = {s: {k: v + o for k, v, o in zip(keys, vals, off[fit])} for s, vals in base.items()}
                items.append({
                    "id": f"{cat}{si}-{ci}", "name": f"{name} ({cname})",
                    "brand": BRANDS[si % len(BRANDS)], "category": cat,
                    "color": hexc, "sizes": sizes,
                })
    return items


CATALOG = _build()
CATALOG_BY_ID = {c["id"]: c for c in CATALOG}