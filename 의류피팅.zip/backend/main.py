import base64
import hashlib
import hmac
import json
import os
import secrets
import shutil
import sqlite3
import time
import uuid
from pathlib import Path

from fastapi import Cookie, Depends, FastAPI, HTTPException, Query, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from catalog import CATALOG, CATALOG_BY_ID
from db import get_db, init_db
from schemas import AuthIn, CatalogAdd, CustomIn, FitRequest, FitResponse, Profile
init_db()
app = FastAPI(title="AI 의류 피팅 플랫폼")

SESSION_DAYS = 14
MAX_CLOSET = 50
# HTTPS로 배포할 때는 환경변수 COOKIE_SECURE=1 로 켜세요.
UPLOAD_DIR = Path(__file__).with_name("uploads")
DIM_KEYS = {"top": ("shoulder", "chest", "waist"), "bottom": ("waist", "hip", "thigh")}
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "0") == "1"

# 옷 단면 너비(cm) — frontend/app.js 의 CLOTHES 와 동일하게 유지
CLOTHES = {
    "top_s":   {"shoulder": 40, "chest": 30, "waist": 28},
    "top_m":   {"shoulder": 43, "chest": 34, "waist": 32},
    "top_l":   {"shoulder": 46, "chest": 38, "waist": 36},
    "pants_s": {"waist": 26, "hip": 32, "thigh": 17},
    "pants_m": {"waist": 30, "hip": 36, "thigh": 20},
    "pants_l": {"waist": 34, "hip": 40, "thigh": 23},
}


# ───────────── 비밀번호 / 세션 ─────────────
def hash_pw(pw: str) -> str:
    salt = os.urandom(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return f"{salt.hex()}:{h.hex()}"


def verify_pw(pw: str, stored: str) -> bool:
    salt_hex, h_hex = stored.split(":")
    h = hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt_hex), n=2**14, r=8, p=1, dklen=32)
    return hmac.compare_digest(h.hex(), h_hex)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def start_session(db: sqlite3.Connection, user_id: int, response: Response):
    token = secrets.token_urlsafe(32)
    max_age = SESSION_DAYS * 86400
    db.execute(
        "INSERT INTO sessions(token_hash, user_id, expires) VALUES (?,?,?)",
        (token_hash(token), user_id, int(time.time()) + max_age),
    )
    db.commit()
    response.set_cookie(
        "session", token, max_age=max_age, httponly=True,
        samesite="lax", secure=COOKIE_SECURE, path="/",
    )


def current_user(session: str | None = Cookie(default=None), db=Depends(get_db)):
    if not session:
        raise HTTPException(401, "로그인이 필요합니다.")
    row = db.execute(
        "SELECT u.id, u.email FROM sessions s JOIN users u ON u.id = s.user_id "
        "WHERE s.token_hash = ? AND s.expires > ?",
        (token_hash(session), int(time.time())),
    ).fetchone()
    if not row:
        raise HTTPException(401, "로그인이 필요합니다.")
    return row


# ───────────── 인증 ─────────────
@app.post("/api/auth/signup", status_code=201)
def signup(data: AuthIn, response: Response, db=Depends(get_db)):
    email = data.email.strip().lower()
    try:
        cur = db.execute(
            "INSERT INTO users(email, pw_hash, created) VALUES (?,?,?)",
            (email, hash_pw(data.password), int(time.time())),
        )
        db.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(409, "이미 가입된 이메일입니다.")
    start_session(db, cur.lastrowid, response)
    return {"email": email}


@app.post("/api/auth/login")
def login(data: AuthIn, response: Response, db=Depends(get_db)):
    email = data.email.strip().lower()
    row = db.execute("SELECT id, pw_hash FROM users WHERE email = ?", (email,)).fetchone()
    if not row or not verify_pw(data.password, row["pw_hash"]):
        raise HTTPException(401, "이메일 또는 비밀번호가 올바르지 않습니다.")
    start_session(db, row["id"], response)
    return {"email": email}


@app.post("/api/auth/logout")
def logout(response: Response, session: str | None = Cookie(default=None), db=Depends(get_db)):
    if session:
        db.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash(session),))
        db.commit()
    response.delete_cookie("session", path="/")
    return {"ok": True}


# ───────────── 내 정보 / 저장된 치수 ─────────────
@app.get("/api/me")
def me(user=Depends(current_user), db=Depends(get_db)):
    row = db.execute("SELECT data FROM profiles WHERE user_id = ?", (user["id"],)).fetchone()
    return {"email": user["email"], "profile": json.loads(row["data"]) if row else None}


@app.put("/api/profile")
def save_profile(profile: Profile, user=Depends(current_user), db=Depends(get_db)):
    db.execute(
        "INSERT INTO profiles(user_id, data) VALUES (?, ?) "
        "ON CONFLICT(user_id) DO UPDATE SET data = excluded.data",
        (user["id"], profile.model_dump_json()),
    )
    db.commit()
    return {"ok": True}


@app.delete("/api/me")
def delete_me(response: Response, user=Depends(current_user), db=Depends(get_db)):
    db.execute("DELETE FROM users WHERE id = ?", (user["id"],))  # 연결된 데이터도 함께 삭제
    db.commit()
    shutil.rmtree(UPLOAD_DIR / str(user["id"]), ignore_errors=True)
    response.delete_cookie("session", path="/")
    return {"ok": True}


# ───────────── 옷 카탈로그 (로그인 불필요) ─────────────
@app.get("/api/catalog")
def catalog(q: str = "", category: str = "", limit: int = Query(60, le=100)):
    q = q.strip().lower()
    out = [c for c in CATALOG
           if (not category or c["category"] == category)
           and (not q or q in c["name"].lower() or q in c["brand"].lower())]
    return out[:limit]


# ───────────── 피팅함 ─────────────
def item_out(r):
    return {"id": r["id"], "source": r["source"], "name": r["name"], "type": r["type"],
            "dims": json.loads(r["dims"]), "has_image": bool(r["image"]), "created": r["created"]}


def check_room(db, user_id):
    n = db.execute("SELECT COUNT(*) FROM closet_items WHERE user_id = ?", (user_id,)).fetchone()[0]
    if n >= MAX_CLOSET:
        raise HTTPException(400, f"피팅함은 최대 {MAX_CLOSET}개까지 저장할 수 있습니다.")


def insert_item(db, user_id, source, name, type_, dims, image):
    db.execute(
        "INSERT INTO closet_items(user_id, source, name, type, dims, image, created) VALUES (?,?,?,?,?,?,?)",
        (user_id, source, name, type_, json.dumps(dims), image, int(time.time())))
    db.commit()


def save_image(user_id: int, b64: str) -> str:
    if "," in b64:
        b64 = b64.split(",", 1)[1]
    try:
        raw = base64.b64decode(b64, validate=True)
    except Exception:
        raise HTTPException(400, "이미지 형식이 올바르지 않습니다.")
    if len(raw) > 400_000 or not raw.startswith(b"\xff\xd8\xff"):
        raise HTTPException(400, "JPEG 이미지(400KB 이하)만 올릴 수 있습니다.")
    folder = UPLOAD_DIR / str(user_id)
    folder.mkdir(parents=True, exist_ok=True)
    name = uuid.uuid4().hex + ".jpg"
    (folder / name).write_bytes(raw)
    return name


@app.get("/api/closet")
def list_closet(user=Depends(current_user), db=Depends(get_db)):
    rows = db.execute("SELECT * FROM closet_items WHERE user_id = ? ORDER BY id DESC", (user["id"],)).fetchall()
    return [item_out(r) for r in rows]


@app.post("/api/closet/catalog", status_code=201)
def add_from_catalog(body: CatalogAdd, user=Depends(current_user), db=Depends(get_db)):
    item = CATALOG_BY_ID.get(body.catalog_id)
    if not item or body.size not in item["sizes"]:
        raise HTTPException(404, "알 수 없는 상품입니다.")
    check_room(db, user["id"])
    insert_item(db, user["id"], "catalog", f'{item["name"]} {body.size}', item["category"],
                item["sizes"][body.size], None)
    return {"ok": True}


@app.post("/api/closet/custom", status_code=201)
def add_custom(body: CustomIn, user=Depends(current_user), db=Depends(get_db)):
    if set(body.dims) != set(DIM_KEYS[body.type]) or not all(10 <= v <= 70 for v in body.dims.values()):
        raise HTTPException(400, "치수는 각 10~70cm 범위로 모두 입력해야 합니다.")
    check_room(db, user["id"])
    image = save_image(user["id"], body.image) if body.image else None
    insert_item(db, user["id"], "custom", body.name.strip(), body.type, body.dims, image)
    return {"ok": True}


@app.get("/api/closet/{item_id}/image")
def closet_image(item_id: int, user=Depends(current_user), db=Depends(get_db)):
    r = db.execute("SELECT image FROM closet_items WHERE id = ? AND user_id = ?",
                   (item_id, user["id"])).fetchone()
    if not r or not r["image"]:
        raise HTTPException(404, "이미지가 없습니다.")
    return FileResponse(UPLOAD_DIR / str(user["id"]) / r["image"], media_type="image/jpeg",
                        headers={"Cache-Control": "private, max-age=3600"})


@app.delete("/api/closet/{item_id}")
def delete_closet(item_id: int, user=Depends(current_user), db=Depends(get_db)):
    r = db.execute("SELECT image FROM closet_items WHERE id = ? AND user_id = ?",
                   (item_id, user["id"])).fetchone()
    if r and r["image"]:
        (UPLOAD_DIR / str(user["id"]) / r["image"]).unlink(missing_ok=True)
    db.execute("DELETE FROM closet_items WHERE id = ? AND user_id = ?", (item_id, user["id"]))
    db.commit()
    return {"ok": True}

# ───────────── 핏 판정 (기존) ─────────────
def judge(diff: float) -> str:
    if diff < 0.5:
        return "타이트"
    return "적당" if diff <= 5 else "여유"


@app.post("/api/fit", response_model=FitResponse)
def fit(req: FitRequest):
    cloth = CLOTHES.get(req.cloth_id)
    if cloth is None:
        raise HTTPException(404, "알 수 없는 의류입니다.")
    body = req.body.model_dump()
    parts = {k: judge(v - body[k]) for k, v in cloth.items()}
    return FitResponse(cloth_id=req.cloth_id, parts=parts)


# 프론트엔드 (반드시 맨 마지막)
HERE = Path(__file__).resolve().parent
FRONTEND = HERE / "frontend" if (HERE / "frontend").exists() else HERE.parent / "frontend"
app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")