from typing import Literal

from pydantic import BaseModel, Field


class Body(BaseModel):
    gender: str
    height: float = Field(ge=100, le=230)
    shoulder: float
    chest: float
    waist: float
    hip: float
    arm: float
    thigh: float
    calf: float
    foot_mm: int = Field(ge=150, le=350)


class FitRequest(BaseModel):
    body: Body
    cloth_id: str


class FitResponse(BaseModel):
    cloth_id: str
    parts: dict[str, str]  # 예: {"chest": "적당"}


# ───── 계정 / 저장 ─────
class AuthIn(BaseModel):
    email: str = Field(max_length=254, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    password: str = Field(min_length=8, max_length=128)


class Measures(BaseModel):
    height: float = Field(ge=100, le=230)
    shoulder: float = Field(ge=20, le=70)
    chest: float = Field(ge=15, le=60)
    waist: float = Field(ge=15, le=60)
    hip: float = Field(ge=15, le=60)
    arm: float = Field(ge=3, le=25)
    thigh: float = Field(ge=5, le=40)
    calf: float = Field(ge=5, le=30)
    foot: float = Field(ge=150, le=350)


class Profile(BaseModel):
    gender: Literal["male", "female"]
    hair: str = Field(max_length=20)
    hairColor: str = Field(pattern=r"^#[0-9a-fA-F]{6}$")
    shoe: str = Field(max_length=20)
    shoeColor: str = Field(pattern=r"^#[0-9a-fA-F]{6}$")
    body: Measures


class ClosetIn(BaseModel):
    cloth_id: str = Field(max_length=40)
    fit: dict[str, str]


# ───── 옷 찾기 / 내 옷 ─────
class CatalogAdd(BaseModel):
    catalog_id: str = Field(max_length=20)
    size: str = Field(max_length=4)


class CustomIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    type: Literal["top", "bottom"]
    dims: dict[str, float]
    image: str | None = Field(default=None, max_length=700_000)