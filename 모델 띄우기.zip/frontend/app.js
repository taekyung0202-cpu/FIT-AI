import * as THREE from 'three';

import {
  OrbitControls
} from 'three/addons/controls/OrbitControls.js';

import {
  GLTFLoader
} from 'three/addons/loaders/GLTFLoader.js';

import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';


/* =====================================================
   기본 설정
===================================================== */

const MODEL_URL = './female.glb';


const DEFAULTS = {

  female: {

    height: 162,
    shoulder: 38,
    chest: 29,
    waist: 25,
    hip: 34,
    arm: 8,
    thigh: 17,
    calf: 11

  },

  male: {

    height: 175,
    shoulder: 44,
    chest: 34,
    waist: 30,
    hip: 35,
    arm: 10,
    thigh: 18,
    calf: 12

  }

};


const SLIDERS = [

  ['height', '키', 140, 200],

  ['shoulder', '어깨너비', 30, 56],

  ['chest', '가슴너비', 22, 45],

  ['waist', '허리너비', 18, 42],

  ['hip', '엉덩이너비', 26, 46],

  ['arm', '팔 두께', 5, 16],

  ['thigh', '허벅지 두께', 10, 28],

  ['calf', '종아리 두께', 7, 18]

];


const CLOTH = {

  shoulder: 43,

  chest: 34,

  waist: 32,

  hip: 36,

  thigh: 20

};


const state = {

  gender: 'female',

  body: {

    ...DEFAULTS.female

  }

};


/* =====================================================
   HTML
===================================================== */

const viewer =
  document.getElementById('viewer');

const sliders =
  document.getElementById('sliders');

const fitResult =
  document.getElementById('fitResult');

const loading =
  document.getElementById('loading');

const modelStatus =
  document.getElementById('modelStatus');

const femaleBtn =
  document.getElementById('femaleBtn');

const maleBtn =
  document.getElementById('maleBtn');

const resetBtn =
  document.getElementById('resetBtn');


/*
  HTML이 제대로 연결됐는지 확인
*/

console.log(
  'viewer =',
  viewer
);

console.log(
  'sliders =',
  sliders
);

console.log(
  'femaleBtn =',
  femaleBtn
);


/* =====================================================
   Three.js
===================================================== */

const scene =
  new THREE.Scene();


scene.background =
  new THREE.Color(
    0x101217
  );


const camera =
  new THREE.PerspectiveCamera(

    35,

    1,

    0.01,

    100

  );


camera.position.set(

  0,

  0.9,

  3.0

);


const renderer =
  new THREE.WebGLRenderer({

    antialias: true

  });


renderer.setPixelRatio(

  Math.min(

    window.devicePixelRatio,

    2

  )

);


renderer.outputColorSpace =
  THREE.SRGBColorSpace;


viewer.appendChild(
  renderer.domElement
);


/* =====================================================
   OrbitControls
===================================================== */

const controls =
  new OrbitControls(

    camera,

    renderer.domElement

  );


controls.enableDamping =
  true;


controls.dampingFactor =
  0.08;


controls.minDistance =
  0.5;


controls.maxDistance =
  8;


/* =====================================================
   조명
===================================================== */

scene.add(

  new THREE.HemisphereLight(

    0xffffff,

    0x333344,

    2.0

  )

);


const keyLight =
  new THREE.DirectionalLight(

    0xffffff,

    2.5

  );


keyLight.position.set(

  3,

  5,

  4

);


scene.add(
  keyLight
);


const fillLight =
  new THREE.DirectionalLight(

    0xffffff,

    1.2

  );


fillLight.position.set(

  -3,

  3,

  2

);


scene.add(
  fillLight
);


/* =====================================================
   바닥
===================================================== */

const floor =
  new THREE.Mesh(

    new THREE.CircleGeometry(

      2.5,

      64

    ),

    new THREE.MeshStandardMaterial({

      color: 0x282d36,

      roughness: 0.9

    })

  );


floor.rotation.x =
  -Math.PI / 2;


scene.add(
  floor
);


/* =====================================================
   아바타
===================================================== */

const avatar =
  new THREE.Group();


scene.add(
  avatar
);


/* =====================================================
   GLB
===================================================== */

const loader =
  new GLTFLoader();


let originalModel =
  null;


let currentModel =
  null;


/* =====================================================
   화면 크기
===================================================== */

function resize() {

  const width =
    viewer.clientWidth;

  const height =
    viewer.clientHeight;


  if (

    width <= 0 ||

    height <= 0

  ) {

    return;

  }


  renderer.setSize(

    width,

    height,

    false

  );


  camera.aspect =
    width / height;


  camera.updateProjectionMatrix();

}


window.addEventListener(
  'resize',
  resize
);


resize();


/* =====================================================
   GLB 재질
===================================================== */

function prepareModel(model) {

  model.traverse(

    object => {

      if (!object.isMesh) {

        return;

      }


      object.frustumCulled =
        false;


      const materials =
        Array.isArray(

          object.material

        )

          ? object.material

          : [object.material];


      materials.forEach(

        material => {

          if (!material) {

            return;

          }


          /*
            메시가 사라지는 문제 방지
          */

          material.side =
            THREE.DoubleSide;


          material.needsUpdate =
            true;

        }

      );


      object.castShadow =
        true;


      object.receiveShadow =
        true;

    }

  );

}


/* =====================================================
   GLB 정보
===================================================== */

function inspectModel(model) {

  let meshCount = 0;

  let boneCount = 0;

  let morphCount = 0;


  model.traverse(

    object => {

      if (object.isMesh) {

        meshCount++;

        if (

          object.morphTargetDictionary

        ) {

          const names =
            Object.keys(

              object.morphTargetDictionary

            );


          morphCount +=
            names.length;


          console.log(

            'MORPH TARGET:',

            names

          );

        }

      }


      if (object.isBone) {

        boneCount++;

        console.log(

          'BONE:',

          object.name

        );

      }

    }

  );


  console.log(
    '================================'
  );

  console.log(
    'GLB 검사 결과'
  );

  console.log(
    'Mesh:',
    meshCount
  );

  console.log(
    'Bone:',
    boneCount
  );

  console.log(
    'Morph:',
    morphCount
  );

  console.log(
    '================================'
  );

}


/* =====================================================
   GLB 크기 정리
===================================================== */

function normalizeModel(model) {

  const box =
    new THREE.Box3()
      .setFromObject(model);


  const size =
    new THREE.Vector3();


  box.getSize(
    size
  );


  console.log(
    'GLB 원본 크기:',
    size
  );


  if (
    size.y <= 0
  ) {

    console.error(
      '모델 높이를 계산할 수 없습니다.'
    );

    return;

  }


  /*
    목표 높이

    162cm = 1.62
  */

  const targetHeight =
    state.body.height / 100;


  const scale =
    targetHeight / size.y;


  model.scale.setScalar(
    scale
  );


  /*
    다시 계산
  */

  const box2 =
    new THREE.Box3()
      .setFromObject(model);


  const center =
    new THREE.Vector3();


  box2.getCenter(
    center
  );


  /*
    좌우 중앙
  */

  model.position.x -=
    center.x;


  /*
    앞뒤 중앙
  */

  model.position.z -=
    center.z;


  /*
    바닥
  */

  const box3 =
    new THREE.Box3()
      .setFromObject(model);


  model.position.y -=
    box3.min.y;

}


/* =====================================================
   GLB 로드
===================================================== */

async function loadModel() {

  try {

    loading.classList.remove(
      'hidden'
    );


    modelStatus.textContent =
      'female.glb 불러오는 중...';


    console.log(
      'GLB 로딩:',
      MODEL_URL
    );


    const gltf =
      await loader.loadAsync(

        MODEL_URL

      );


    originalModel =
      gltf.scene;


    prepareModel(
      originalModel
    );


    inspectModel(
      originalModel
    );


    console.log(
      'GLB 로딩 성공:',
      MODEL_URL
    );


    modelStatus.textContent =
      'female.glb 로딩 완료';


    loading.classList.add(
      'hidden'
    );


    rebuild();


  }

  catch (error) {

    console.error(
      'GLB 로딩 실패:',
      error
    );


    modelStatus.textContent =
      'GLB 로딩 실패';


    loading.textContent =
      'female.glb를 찾을 수 없습니다.';


  }

}


/* =====================================================
   모델 복제
===================================================== */

function cloneModel() {

  if (
    !originalModel
  ) {

    return null;

  }


  /*
    SkinnedMesh / Skeleton
    정상 복제
  */

  const model =
    SkeletonUtils.clone(
      originalModel
    );


  prepareModel(
    model
  );


  return model;

}


/* =====================================================
   기존 모델 제거
===================================================== */

function clearAvatar() {

  while (
    avatar.children.length
  ) {

    avatar.remove(
      avatar.children[0]
    );

  }

}


/* =====================================================
   Morph Target 찾기
===================================================== */

function getMorphs(model) {

  const result = [];


  model.traverse(

    object => {

      if (
        !object.isMesh
      ) {

        return;

      }


      if (
        !object.morphTargetDictionary
      ) {

        return;

      }


      Object.keys(

        object.morphTargetDictionary

      ).forEach(

        name => {

          result.push({

            mesh: object,

            name,

            index:
              object
                .morphTargetDictionary[
                  name
                ]

          });

        }

      );

    }

  );


  return result;

}


/* =====================================================
   Morph 검색
===================================================== */

function findMorph(
  morphs,
  keywords
) {

  for (
    const morph of morphs
  ) {

    const name =
      morph.name.toLowerCase();


    for (
      const keyword of keywords
    ) {

      if (
        name.includes(
          keyword
        )
      ) {

        return morph;

      }

    }

  }


  return null;

}


/* =====================================================
   Morph 체형 적용
===================================================== */

function applyMorphBody(model) {

  const morphs =
    getMorphs(model);


  console.log(
    '현재 Morph 개수:',
    morphs.length
  );


  if (
    morphs.length === 0
  ) {

    return false;

  }


  /*
    모든 Morph 초기화
  */

  model.traverse(

    object => {

      if (
        !object.morphTargetInfluences
      ) {

        return;

      }


      object.morphTargetInfluences
        .fill(0);

    }

  );


  const p =
    state.body;


  const d =
    DEFAULTS.female;


  /*
    어깨
  */

  const shoulder =
    findMorph(

      morphs,

      [
        'shoulder',
        'shoulders'
      ]

    );


  if (shoulder) {

    shoulder.mesh
      .morphTargetInfluences[
        shoulder.index
      ] =

      THREE.MathUtils.clamp(

        (
          p.shoulder -
          d.shoulder
        ) / 15,

        -1,

        1

      );

  }


  /*
    가슴
  */

  const chest =
    findMorph(

      morphs,

      [
        'chest',
        'breast',
        'bust'
      ]

    );


  if (chest) {

    chest.mesh
      .morphTargetInfluences[
        chest.index
      ] =

      THREE.MathUtils.clamp(

        (
          p.chest -
          d.chest
        ) / 12,

        -1,

        1

      );

  }


  /*
    허리
  */

  const waist =
    findMorph(

      morphs,

      [
        'waist',
        'abdomen',
        'belly'
      ]

    );


  if (waist) {

    waist.mesh
      .morphTargetInfluences[
        waist.index
      ] =

      THREE.MathUtils.clamp(

        (
          p.waist -
          d.waist
        ) / 12,

        -1,

        1

      );

  }


  /*
    엉덩이
  */

  const hip =
    findMorph(

      morphs,

      [
        'hip',
        'hips',
        'glute'
      ]

    );


  if (hip) {

    hip.mesh
      .morphTargetInfluences[
        hip.index
      ] =

      THREE.MathUtils.clamp(

        (
          p.hip -
          d.hip
        ) / 12,

        -1,

        1

      );

  }


  /*
    팔
  */

  const arm =
    findMorph(

      morphs,

      [
        'arm',
        'arms'
      ]

    );


  if (arm) {

    arm.mesh
      .morphTargetInfluences[
        arm.index
      ] =

      THREE.MathUtils.clamp(

        (
          p.arm -
          d.arm
        ) / 5,

        -1,

        1

      );

  }


  /*
    허벅지
  */

  const thigh =
    findMorph(

      morphs,

      [
        'thigh',
        'upperleg'
      ]

    );


  if (thigh) {

    thigh.mesh
      .morphTargetInfluences[
        thigh.index
      ] =

      THREE.MathUtils.clamp(

        (
          p.thigh -
          d.thigh
        ) / 8,

        -1,

        1

      );

  }


  /*
    종아리
  */

  const calf =
    findMorph(

      morphs,

      [
        'calf',
        'shin',
        'lowerleg'
      ]

    );


  if (calf) {

    calf.mesh
      .morphTargetInfluences[
        calf.index
      ] =

      THREE.MathUtils.clamp(

        (
          p.calf -
          d.calf
        ) / 6,

        -1,

        1

      );

  }


  return true;

}


/* =====================================================
   Bone 체형 적용
===================================================== */

function applyBoneBody(model) {

  const bones = [];


  model.traverse(

    object => {

      if (
        object.isBone
      ) {

        bones.push(
          object
        );

      }

    }

  );


  if (
    bones.length === 0
  ) {

    console.warn(
      'Bone이 없습니다.'
    );

    return;

  }


  const p =
    state.body;


  const d =
    DEFAULTS.female;


  function bone(
    regex
  ) {

    return bones.find(

      b =>
        regex.test(

          b.name.toLowerCase()

        )

    );

  }


  /*
    골반
  */

  const pelvis =
    bone(
      /pelvis|hips/
    );


  if (pelvis) {

    const r =
      p.hip / d.hip;


    pelvis.scale.x *= r;

    pelvis.scale.z *= r;

  }


  /*
    가슴
  */

  const chest =
    bone(
      /chest|spine03|spine3/
    );


  if (chest) {

    const r =
      p.chest / d.chest;


    chest.scale.x *= r;

    chest.scale.z *= r;

  }


  /*
    허리
  */

  const waist =
    bone(
      /waist|spine02|spine2/
    );


  if (waist) {

    const r =
      p.waist / d.waist;


    waist.scale.x *= r;

    waist.scale.z *= r;

  }


  /*
    팔
  */

  const armRatio =
    p.arm / d.arm;


  bones.forEach(

    b => {

      const name =
        b.name.toLowerCase();


      if (

        name.includes(
          'upperarm'
        ) ||

        name.includes(
          'leftarm'
        ) ||

        name.includes(
          'rightarm'
        )

      ) {

        b.scale.x *=
          armRatio;

        b.scale.z *=
          armRatio;

      }

    }

  );


  /*
    허벅지
  */

  const thighRatio =
    p.thigh / d.thigh;


  bones.forEach(

    b => {

      const name =
        b.name.toLowerCase();


      if (

        name.includes(
          'thigh'
        ) ||

        name.includes(
          'upleg'
        )

      ) {

        b.scale.x *=
          thighRatio;

        b.scale.z *=
          thighRatio;

      }

    }

  );


  /*
    종아리
  */

  const calfRatio =
    p.calf / d.calf;


  bones.forEach(

    b => {

      const name =
        b.name.toLowerCase();


      if (

        name.includes(
          'calf'
        ) ||

        name.includes(
          'lowerleg'
        )

      ) {

        b.scale.x *=
          calfRatio;

        b.scale.z *=
          calfRatio;

      }

    }

  );

}


/* =====================================================
   체형 적용
===================================================== */

function applyBody(
  model
) {

  /*
    Morph Target 우선
  */

  const morphApplied =
    applyMorphBody(
      model
    );


  /*
    Morph가 없으면 Bone
  */

  if (
    !morphApplied
  ) {

    console.log(
      'Morph 없음 → Bone 방식'
    );


    applyBoneBody(
      model
    );

  }

  else {

    console.log(
      'Morph 방식으로 체형 적용'
    );

  }

}


/* =====================================================
   모델 중앙 / 바닥
===================================================== */

function centerModel(
  model
) {

  const box =
    new THREE.Box3()
      .setFromObject(model);


  const center =
    new THREE.Vector3();


  box.getCenter(
    center
  );


  model.position.x -=
    center.x;


  model.position.z -=
    center.z;


  const box2 =
    new THREE.Box3()
      .setFromObject(model);


  model.position.y -=
    box2.min.y;

}


/* =====================================================
   카메라
===================================================== */

function updateCamera(
  model
) {

  const box =
    new THREE.Box3()
      .setFromObject(model);


  const size =
    new THREE.Vector3();


  box.getSize(
    size
  );


  const height =
    size.y;


  controls.target.set(

    0,

    height * 0.52,

    0

  );


  camera.position.set(

    0,

    height * 0.55,

    Math.max(

      2.7,

      height * 1.8

    )

  );


  camera.near =
    0.01;


  camera.far =
    100;


  camera.updateProjectionMatrix();


  controls.update();

}


/* =====================================================
   모델 재생성
===================================================== */

function rebuild() {

  if (
    !originalModel
  ) {

    return;

  }


  clearAvatar();


  const model =
    cloneModel();


  if (
    !model
  ) {

    return;

  }


  /*
    모델 기본 크기
  */

  normalizeModel(
    model
  );


  /*
    체형
  */

  applyBody(
    model
  );


  /*
    중앙 / 바닥
  */

  centerModel(
    model
  );


  /*
    화면 추가
  */

  avatar.add(
    model
  );


  currentModel =
    model;


  /*
    카메라
  */

  updateCamera(
    model
  );


  /*
    상태
  */

  modelStatus.textContent =
    `female.glb · ${state.body.height}cm`;


  /*
    핏
  */

  updateFit();

}


/* =====================================================
   슬라이더 UI
===================================================== */

function buildSliders() {

  sliders.innerHTML =
    '';


  SLIDERS.forEach(

    ([

      key,

      label,

      min,

      max

    ]) => {

      const box =
        document.createElement(
          'div'
        );


      box.className =
        'slider-box';


      box.innerHTML = `

        <div class="slider-top">

          <span
            class="slider-label"
          >
            ${label}
          </span>

          <span
            class="slider-value"
            id="value-${key}"
          >
            ${state.body[key]}
          </span>

        </div>


        <input
          type="range"
          id="slider-${key}"
          min="${min}"
          max="${max}"
          step="0.5"
          value="${state.body[key]}"
        >

      `;


      sliders.appendChild(
        box
      );


      const input =
        box.querySelector(
          'input'
        );


      input.addEventListener(

        'input',

        event => {

          state.body[key] =
            Number(
              event.target.value
            );


          document.getElementById(

            `value-${key}`

          ).textContent =
            state.body[key];


          rebuild();

        }

      );

    }

  );

}


/* =====================================================
   핏
===================================================== */

function judge(
  diff
) {

  diff =
    Math.abs(diff);


  if (
    diff < 0.5
  ) {

    return 'tight';

  }


  if (
    diff <= 5
  ) {

    return 'fit';

  }


  return 'loose';

}


function updateFit() {

  const data = {

    shoulder:
      judge(
        CLOTH.shoulder -
        state.body.shoulder
      ),

    chest:
      judge(
        CLOTH.chest -
        state.body.chest
      ),

    waist:
      judge(
        CLOTH.waist -
        state.body.waist
      ),

    hip:
      judge(
        CLOTH.hip -
        state.body.hip
      ),

    thigh:
      judge(
        CLOTH.thigh -
        state.body.thigh
      )

  };


  const labels = {

    shoulder: '어깨',

    chest: '가슴',

    waist: '허리',

    hip: '엉덩이',

    thigh: '허벅지'

  };


  const texts = {

    tight: '타이트',

    fit: '적당',

    loose: '여유'

  };


  const classes = {

    tight: 'fit-tight',

    fit: 'fit-good',

    loose: 'fit-loose'

  };


  fitResult.innerHTML =

    Object.entries(data)

      .map(

        ([key, value]) => `

          <div
            class="fit-row"
          >

            <span>
              ${labels[key]}
            </span>

            <strong
              class="${classes[value]}"
            >
              ${texts[value]}
            </strong>

          </div>

        `

      )

      .join('');

}


/* =====================================================
   성별
===================================================== */

function setGender(
  gender
) {

  if (
    gender === 'male'
  ) {

    /*
      아직 male.glb가 없기 때문에
      여성 GLB를 그대로 사용한다.
    */

    alert(
      '현재는 female.glb만 연결되어 있습니다.'
    );

    return;

  }


  state.gender =
    'female';


  state.body = {

    ...DEFAULTS.female

  };


  femaleBtn.classList.add(
    'on'
  );


  maleBtn.classList.remove(
    'on'
  );


  buildSliders();


  rebuild();

}


/* =====================================================
   버튼
===================================================== */

femaleBtn.addEventListener(

  'click',

  () => {

    setGender(
      'female'
    );

  }

);


maleBtn.addEventListener(

  'click',

  () => {

    setGender(
      'male'
    );

  }

);


resetBtn.addEventListener(

  'click',

  () => {

    state.body = {

      ...DEFAULTS.female

    };


    buildSliders();


    rebuild();

  }

);


/* =====================================================
   시작
===================================================== */

buildSliders();

updateFit();

loadModel();


/* =====================================================
   렌더링
===================================================== */

function animate() {

  requestAnimationFrame(
    animate
  );


  controls.update();


  renderer.render(

    scene,

    camera

  );

}


animate();


/* =====================================================
   외부 연결
===================================================== */

window.fitApp = {

  getProfile() {

    return {

      gender:
        state.gender,

      body:
        {
          ...state.body
        }

    };

  },


  getBody() {

    return {

      ...state.body

    };

  },


  setBody(
    body
  ) {

    Object.assign(

      state.body,

      body

    );


    buildSliders();


    rebuild();

  }

};


/* =====================================================
   디버깅
===================================================== */

window.debugFitting = {

  model() {

    return currentModel;

  },


  morphs() {

    if (
      !currentModel
    ) {

      return [];

    }


    const morphs =
      getMorphs(
        currentModel
      );


    console.log(
      morphs.map(
        m => m.name
      )
    );


    return morphs;

  }

};


console.log(
  'AI 의류 피팅 시작'
);